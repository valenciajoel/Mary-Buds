#include <string>

typedef std::string String;
